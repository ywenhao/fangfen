<?php
define("U","lanjingling6699");
define("P","lanjingling6699");
?>