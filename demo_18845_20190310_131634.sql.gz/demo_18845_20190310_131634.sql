-- MySQL dump 10.13  Distrib 5.5.57, for Linux (x86_64)
--
-- Host: localhost    Database: demo_18845
-- ------------------------------------------------------
-- Server version	5.5.57-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `codepay_order`
--

DROP TABLE IF EXISTS `codepay_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codepay_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pay_id` varchar(50) NOT NULL COMMENT '用户ID或订单ID',
  `money` decimal(6,2) unsigned NOT NULL COMMENT '实际金额',
  `price` decimal(6,2) unsigned NOT NULL COMMENT '原价',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '支付方式',
  `pay_no` varchar(100) NOT NULL COMMENT '流水号',
  `param` varchar(200) DEFAULT NULL COMMENT '自定义参数',
  `pay_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `pay_tag` varchar(100) NOT NULL DEFAULT '0' COMMENT '金额的备注',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `creat_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `up_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `main` (`pay_id`,`pay_time`,`money`,`type`,`pay_tag`),
  UNIQUE KEY `pay_no` (`pay_no`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用于区分是否已经处理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codepay_order`
--

LOCK TABLES `codepay_order` WRITE;
/*!40000 ALTER TABLE `codepay_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `codepay_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `codepay_user`
--

DROP TABLE IF EXISTS `codepay_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codepay_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user` varchar(100) NOT NULL DEFAULT '' COMMENT '用户名',
  `money` decimal(6,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `vip` int(1) NOT NULL DEFAULT '0' COMMENT '会员开通',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codepay_user`
--

LOCK TABLES `codepay_user` WRITE;
/*!40000 ALTER TABLE `codepay_user` DISABLE KEYS */;
INSERT INTO `codepay_user` VALUES (1,'admin',0.00,0,0);
/*!40000 ALTER TABLE `codepay_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_administrator`
--

DROP TABLE IF EXISTS `tb_administrator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_administrator` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(20) DEFAULT NULL COMMENT '盐',
  `gender` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0保密，1男，2女',
  `level` int(11) DEFAULT '0' COMMENT '等级',
  `birthday` int(11) NOT NULL DEFAULT '0' COMMENT '生日',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '邮箱',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `is_check` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '0禁用',
  `last_login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '注册时间',
  PRIMARY KEY (`id`),
  KEY `user_login` (`username`) USING BTREE,
  KEY `user_nickname` (`nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_administrator`
--

LOCK TABLES `tb_administrator` WRITE;
/*!40000 ALTER TABLE `tb_administrator` DISABLE KEYS */;
INSERT INTO `tb_administrator` VALUES (1,'admin','97df3e1c1b9d1f65bfbe258a5bdcff71','asX5eTXA',0,0,0,'微圈','','123@qq.com','20181222/a29cd654cf4469dba35e34e1be9d8e79.png',1,'',0,1545429347,0);
/*!40000 ALTER TABLE `tb_administrator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_auth_group`
--

DROP TABLE IF EXISTS `tb_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_auth_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `module` varchar(10) NOT NULL DEFAULT 'admin' COMMENT '所属模块',
  `level` int(11) NOT NULL COMMENT '角色等级',
  `title` varchar(200) NOT NULL COMMENT '用户组中文名称',
  `status` tinyint(1) NOT NULL COMMENT '状态：为1正常，为0禁用',
  `rules` text COMMENT '用户组拥有的规则id， 多个规则","隔开',
  `notation` varchar(100) DEFAULT NULL COMMENT '组别描述',
  `pic` varchar(200) DEFAULT NULL COMMENT '角色图标',
  `recom` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐首页显示',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '编辑时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_auth_group`
--

LOCK TABLES `tb_auth_group` WRITE;
/*!40000 ALTER TABLE `tb_auth_group` DISABLE KEYS */;
INSERT INTO `tb_auth_group` VALUES (1,'admin',1090,'超级管理员',1,'1,2,3,4,5,6,7,8,9,10,23,24,25,26,27,11,12,15,14,16,17,18,19,20,21,22','我能干任何事','#dd4b39',0,1502780231,1544865665),(2,'admin',1,'后台浏览',1,'1,2,3,4,5,10,23,24,15,14,16,19','只能查看列表','#f39c12',0,1502784113,1534808239),(3,'admin',0,'雇主',1,NULL,'',NULL,0,1536592696,0);
/*!40000 ALTER TABLE `tb_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_auth_group_access`
--

DROP TABLE IF EXISTS `tb_auth_group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_auth_group_access` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(11) unsigned NOT NULL COMMENT '用户id',
  `group_id` int(11) unsigned NOT NULL COMMENT '用户组id',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '编辑时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_auth_group_access`
--

LOCK TABLES `tb_auth_group_access` WRITE;
/*!40000 ALTER TABLE `tb_auth_group_access` DISABLE KEYS */;
INSERT INTO `tb_auth_group_access` VALUES (7,1,1,0,0);
/*!40000 ALTER TABLE `tb_auth_group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_auth_rule`
--

DROP TABLE IF EXISTS `tb_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `pid` int(11) unsigned NOT NULL COMMENT '父id',
  `module` varchar(10) NOT NULL DEFAULT 'admin' COMMENT '权限节点所属模块',
  `level` tinyint(1) NOT NULL COMMENT '1-项目;2-模块;3-操作',
  `name` varchar(80) NOT NULL COMMENT '规则唯一标识',
  `title` varchar(20) NOT NULL COMMENT '规则中文名称',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
  `ismenu` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否导航',
  `condition` varchar(200) DEFAULT NULL COMMENT '规则表达式，为空表示存在就验证，不为空表示按照条件验证',
  `icon` varchar(50) DEFAULT NULL COMMENT '节点图标',
  `sorts` mediumint(8) DEFAULT '50' COMMENT '排序',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '编辑时间',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `level` (`level`) USING BTREE,
  KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_auth_rule`
--

LOCK TABLES `tb_auth_rule` WRITE;
/*!40000 ALTER TABLE `tb_auth_rule` DISABLE KEYS */;
INSERT INTO `tb_auth_rule` VALUES (1,0,'admin',1,'Index/index','后台首页',1,1,1,NULL,'fa fa-home',1000,1532168003,1532169104),(2,0,'admin',1,'index','系统设置',1,1,1,NULL,'fa fa-dashboard',1200,1532168495,1532169112),(3,2,'admin',2,'index/index','网站设置',1,1,1,NULL,'fa fa-circle-o',1,1532168566,1532169121),(4,2,'admin',2,'index/profile','资料设置',1,1,1,NULL,'fa fa-circle-o',2,1532169226,0),(5,2,'admin',2,'index/uploads','文件管理',1,1,1,NULL,'fa fa-circle-o',3,1532169267,0),(6,0,'admin',1,'auth','权限管理',1,1,1,NULL,'fa fa-users',1300,1532177458,0),(7,6,'admin',2,'auth_admin/index','管理员列表',1,1,1,NULL,'fa fa-user-o',1,1532177508,1532189126),(8,6,'admin',2,'auth_group/index','角色列表',1,1,1,NULL,'fa fa-vcard',2,1532177534,1532188696),(9,6,'admin',2,'auth_rule/index','菜单规则列表',1,1,1,NULL,'fa fa-user-circle',3,1532177559,1532188705),(10,0,'admin',1,'member','会员管理',1,1,1,NULL,'fa fa-users',1400,1532177701,1532241958),(11,0,'admin',1,'invitation/index','邀请管理',1,1,1,NULL,'fa fa-users',1500,1532177768,0),(12,0,'admin',1,'task','任务管理',1,1,1,NULL,'fa fa-dashboard',1600,1532177915,0),(14,12,'admin',2,'taskjoin/index','任务数据',1,1,1,NULL,'fa fa-circle-o',3,1532177961,0),(15,12,'admin',2,'task/index','任务列表',1,1,1,NULL,'fa fa-circle-o',2,1532178005,0),(16,12,'admin',2,'taskcategory/index','分类列表',1,1,1,NULL,'fa fa-circle-o',4,1532178030,0),(17,0,'admin',1,'channel/index','渠道管理',1,1,1,NULL,'fa fa-dashboard',1700,1532178159,0),(18,0,'admin',1,'recharge/index','充值管理',1,1,1,NULL,'fa fa-dashboard',1800,1532178193,0),(19,0,'admin',1,'withdraw/index','提现管理',1,1,1,NULL,'fa fa-dashboard',1900,1532178216,0),(20,0,'admin',1,'notice/index','公告管理',1,1,1,NULL,'fa fa-home',2000,1532178266,0),(21,0,'admin',1,'banner/index','轮播图管理',1,0,1,NULL,'fa fa-dashboard',2100,1532178294,1545377325),(22,0,'admin',1,'feedback/index','反馈管理',1,0,1,NULL,'fa fa-dashboard',2200,1532178317,1545377688),(23,10,'admin',2,'member/index','会员列表',1,1,1,NULL,'fa fa-circle-o',1,1532241379,0),(24,10,'admin',2,'member/charge','充值记录',1,1,1,NULL,'fa fa-circle-o',2,1532241433,0),(25,10,'admin',2,'credit_record/index','资金流水',1,1,1,NULL,'fa fa-circle-o',50,1536659743,0),(26,10,'admin',2,'member/fenzu','会员级别',1,1,1,NULL,'fa fa-circle-o',51,1536659743,0),(27,10,'admin',2,'member/renwufenzu','任务限制',1,1,1,NULL,'fa fa-circle-o',52,1536659743,0);
/*!40000 ALTER TABLE `tb_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_banner`
--

DROP TABLE IF EXISTS `tb_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_banner` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `order_by` int(10) unsigned NOT NULL DEFAULT '0',
  `is_display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order_by` (`is_display`,`order_by`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='轮播图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_banner`
--

LOCK TABLES `tb_banner` WRITE;
/*!40000 ALTER TABLE `tb_banner` DISABLE KEYS */;
INSERT INTO `tb_banner` VALUES (1,'1','20180627/520faf2a77e4350d0030a6e83e31573c.png','http://www.1.com',3,1,1541966534,1524738575);
/*!40000 ALTER TABLE `tb_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_channel`
--

DROP TABLE IF EXISTS `tb_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '渠道名',
  `order_by` int(11) DEFAULT '0',
  `is_display` tinyint(3) DEFAULT '0' COMMENT '1显示',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_channel`
--

LOCK TABLES `tb_channel` WRITE;
/*!40000 ALTER TABLE `tb_channel` DISABLE KEYS */;
INSERT INTO `tb_channel` VALUES (4,'广告商',0,1,1545426679,1520213049);
/*!40000 ALTER TABLE `tb_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_charge`
--

DROP TABLE IF EXISTS `tb_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_charge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作管理员ID，0代表系统',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(10) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT 'credit1积分，credit2余额',
  `num` decimal(10,2) DEFAULT '0.00' COMMENT '充值数量，负数代表减少',
  `remark` varchar(200) CHARACTER SET utf8 NOT NULL,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_charge`
--

LOCK TABLES `tb_charge` WRITE;
/*!40000 ALTER TABLE `tb_charge` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_charge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_code`
--

DROP TABLE IF EXISTS `tb_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) CHARACTER SET utf8 NOT NULL,
  `email` varchar(20) DEFAULT NULL COMMENT '邮箱',
  `code` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '验证码',
  `status` tinyint(3) DEFAULT '0' COMMENT '1已使用',
  `ip` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT 'IP地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_code`
--

LOCK TABLES `tb_code` WRITE;
/*!40000 ALTER TABLE `tb_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_config`
--

DROP TABLE IF EXISTS `tb_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting` text COMMENT '设置选项，序列化存储',
  `update_time` int(11) DEFAULT '0' COMMENT '修改时间',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_config`
--

LOCK TABLES `tb_config` WRITE;
/*!40000 ALTER TABLE `tb_config` DISABLE KEYS */;
INSERT INTO `tb_config` VALUES (1,'a:34:{s:5:\"title\";s:42:\"微圈，一个朋友圈会赚钱的工具\";s:4:\"logo\";s:45:\"20181222/d7c0a87fc1ae9964070aae4359774b25.png\";s:2:\"qq\";s:0:\"\";s:6:\"wechat\";s:0:\"\";s:9:\"copyright\";s:0:\"\";s:10:\"baidu_stat\";s:0:\"\";s:10:\"baidu_chat\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:12:\"seo_keywords\";s:0:\"\";s:15:\"seo_description\";s:0:\"\";s:9:\"SMTP_HOST\";s:0:\"\";s:9:\"SMTP_PORT\";s:0:\"\";s:9:\"SMTP_USER\";s:0:\"\";s:9:\"SMTP_PASS\";s:0:\"\";s:10:\"FROM_EMAIL\";s:0:\"\";s:9:\"FROM_NAME\";s:0:\"\";s:10:\"TEST_EMAIL\";s:0:\"\";s:27:\"invitation_first_task_award\";s:1:\"0\";s:26:\"invitation_withdraw_rebate\";s:1:\"0\";s:17:\"invitation_rebate\";s:1:\"0\";s:17:\"sign_give_credit1\";s:2:\"20\";s:18:\"sign_continue_give\";s:1:\"2\";s:12:\"withdraw_min\";s:3:\"100\";s:12:\"withdraw_fee\";s:1:\"5\";s:3:\"fee\";s:1:\"0\";s:6:\"period\";s:8:\"2#4#8#12\";s:5:\"speed\";s:1:\"5\";s:10:\"push_check\";s:1:\"0\";s:7:\"top_fee\";s:2:\"10\";s:12:\"top_max_hour\";s:2:\"10\";s:24:\"receive_order_limit_time\";s:3:\"120\";s:22:\"check_order_limit_time\";s:1:\"1\";s:16:\"join_task_detail\";s:0:\"\";s:16:\"push_task_detail\";s:0:\"\";}',1545467833,1516952068);
/*!40000 ALTER TABLE `tb_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_credit_record`
--

DROP TABLE IF EXISTS `tb_credit_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_credit_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` enum('credit1','credit2') NOT NULL COMMENT 'credit1积分，credit2余额',
  `num` decimal(10,2) DEFAULT '0.00' COMMENT '充值数量，负数代表减少',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '标题',
  `remark` varchar(200) NOT NULL,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE,
  KEY `uid_2` (`uid`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_credit_record`
--

LOCK TABLES `tb_credit_record` WRITE;
/*!40000 ALTER TABLE `tb_credit_record` DISABLE KEYS */;
INSERT INTO `tb_credit_record` VALUES (1,184,'credit2',1.00,'会员充值','支付宝充值金额：1。',1545429758);
/*!40000 ALTER TABLE `tb_credit_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_feedback`
--

DROP TABLE IF EXISTS `tb_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_feedback` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '反馈id',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `content` varchar(500) NOT NULL DEFAULT '' COMMENT '反馈内容',
  `ip` varchar(20) NOT NULL DEFAULT '0' COMMENT 'ip地址',
  `ip_addr` varchar(200) NOT NULL DEFAULT '' COMMENT '地理位置',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '上级id',
  `is_reply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否回复',
  `son` int(11) NOT NULL DEFAULT '0' COMMENT '子反馈数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`parent_id`),
  KEY `update_time` (`update_time`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='反馈表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feedback`
--

LOCK TABLES `tb_feedback` WRITE;
/*!40000 ALTER TABLE `tb_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_follows`
--

DROP TABLE IF EXISTS `tb_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `follow_uid` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_follows`
--

LOCK TABLES `tb_follows` WRITE;
/*!40000 ALTER TABLE `tb_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_invitation_code`
--

DROP TABLE IF EXISTS `tb_invitation_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_invitation_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='邀请码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_invitation_code`
--

LOCK TABLES `tb_invitation_code` WRITE;
/*!40000 ALTER TABLE `tb_invitation_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_invitation_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_invitation_log`
--

DROP TABLE IF EXISTS `tb_invitation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_invitation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '用户名',
  `invite_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '邀请用户id',
  `invite_username` varchar(50) NOT NULL DEFAULT '' COMMENT '邀请用户名',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `invite_uid` (`invite_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='邀请记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_invitation_log`
--

LOCK TABLES `tb_invitation_log` WRITE;
/*!40000 ALTER TABLE `tb_invitation_log` DISABLE KEYS */;
INSERT INTO `tb_invitation_log` VALUES (1,188,'13652315733',189,'15770677217',1545455339,0);
/*!40000 ALTER TABLE `tb_invitation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_invitation_rebate_record`
--

DROP TABLE IF EXISTS `tb_invitation_rebate_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_invitation_rebate_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `num` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '充值数量，负数代表减少',
  `task_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '任务id',
  `remark` varchar(200) NOT NULL DEFAULT '',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_invitation_rebate_record`
--

LOCK TABLES `tb_invitation_rebate_record` WRITE;
/*!40000 ALTER TABLE `tb_invitation_rebate_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_invitation_rebate_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_lock`
--

DROP TABLE IF EXISTS `tb_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL COMMENT '网站名称',
  `domain` varchar(255) DEFAULT NULL COMMENT '授权域名',
  `is_forever` tinyint(3) DEFAULT '0' COMMENT '1代表永久授权',
  `to_date` int(11) DEFAULT NULL COMMENT '到期时间戳',
  `update_time` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_lock`
--

LOCK TABLES `tb_lock` WRITE;
/*!40000 ALTER TABLE `tb_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_member`
--

DROP TABLE IF EXISTS `tb_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_member` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL COMMENT '用户名',
  `gender` tinyint(3) DEFAULT '0',
  `parent_uid` int(11) DEFAULT '0' COMMENT '上级ID',
  `experience_value` decimal(10,2) DEFAULT '0.00' COMMENT '经验值',
  `level` int(11) DEFAULT '1' COMMENT '等级',
  `invitation_code` varchar(20) DEFAULT NULL COMMENT '邀请码/手机号',
  `oath_type` tinyint(3) DEFAULT '0' COMMENT '0默认，1微信，2QQ，3微博，4支付宝等',
  `openid` varchar(255) DEFAULT NULL COMMENT '第三方openid',
  `credit1` decimal(10,2) DEFAULT '0.00' COMMENT '积分',
  `credit2` decimal(10,2) DEFAULT '0.00' COMMENT '余额',
  `password` varchar(50) DEFAULT NULL COMMENT '密码',
  `salt` varchar(8) DEFAULT NULL COMMENT '盐',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `is_bind_email` tinyint(3) DEFAULT '0' COMMENT '1已绑定',
  `alipay_account` varchar(50) DEFAULT NULL COMMENT '支付宝账号',
  `alipay_realname` varchar(50) DEFAULT NULL COMMENT '支付宝真实姓名',
  `is_bind_alipay` tinyint(1) DEFAULT '0' COMMENT '1已绑定支付宝',
  `mobile` varchar(20) DEFAULT NULL COMMENT '手机',
  `is_bind_mobile` tinyint(3) DEFAULT '0' COMMENT '1绑定手机',
  `channel_id` int(11) DEFAULT '0' COMMENT '渠道登记',
  `channel_name` varchar(50) DEFAULT NULL COMMENT '渠道名称',
  `channel_desc` varchar(500) DEFAULT NULL COMMENT '渠道描述',
  `is_bind_channel` tinyint(3) DEFAULT '0' COMMENT '1已登记渠道',
  `is_check` tinyint(3) DEFAULT '1' COMMENT '0禁用',
  `is_del` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '删除标识',
  `invite_total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '邀请总人数',
  `invite_rebate` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邀请总返利收益',
  `sign` varchar(30) NOT NULL DEFAULT '' COMMENT '随机签名',
  `sign_continue` int(10) unsigned DEFAULT '0' COMMENT '连续签到天数',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  `img` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='会员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_member`
--

LOCK TABLES `tb_member` WRITE;
/*!40000 ALTER TABLE `tb_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_member_level`
--

DROP TABLE IF EXISTS `tb_member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `have_money` decimal(20,2) NOT NULL,
  `is_effect` int(11) NOT NULL,
  `repay_1` decimal(20,2) NOT NULL,
  `repay_2` decimal(20,2) NOT NULL,
  `repay_3` decimal(20,2) NOT NULL,
  `butie` decimal(20,2) NOT NULL,
  `renwu_repay1` decimal(20,2) NOT NULL,
  `renwu_repay2` decimal(20,2) NOT NULL,
  `fabu_num` int(11) NOT NULL,
  `jiequ_num` int(11) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_member_level`
--

LOCK TABLES `tb_member_level` WRITE;
/*!40000 ALTER TABLE `tb_member_level` DISABLE KEYS */;
INSERT INTO `tb_member_level` VALUES (1,2,'VIP会员',99.00,1,8.00,4.00,2.00,2.00,3.00,5.00,1,2,0),(2,3,'高级VIP会员',299.00,1,16.00,8.00,4.00,2.00,0.00,0.00,0,0,0),(3,4,'特级VIP会员',599.00,1,32.00,16.00,8.00,2.00,0.00,0.00,0,0,0);
/*!40000 ALTER TABLE `tb_member_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_member_renwu_level`
--

DROP TABLE IF EXISTS `tb_member_renwu_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_member_renwu_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `renwu_repay1` decimal(20,2) NOT NULL,
  `renwu_repay2` decimal(20,2) NOT NULL,
  `fabu_num` int(11) NOT NULL,
  `jiequ_num` int(11) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_member_renwu_level`
--

LOCK TABLES `tb_member_renwu_level` WRITE;
/*!40000 ALTER TABLE `tb_member_renwu_level` DISABLE KEYS */;
INSERT INTO `tb_member_renwu_level` VALUES (1,1,'普通会员',0.00,0.00,1,1,0),(2,2,'VIP会员',4.00,2.00,5,2,0),(3,3,'高级VIP会员',8.00,4.00,5,2,0),(4,4,'特级VIP会员',16.00,8.00,5,2,0);
/*!40000 ALTER TABLE `tb_member_renwu_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_notice`
--

DROP TABLE IF EXISTS `tb_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `detail` text,
  `order_by` int(11) DEFAULT '0',
  `is_display` tinyint(3) DEFAULT '1',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_notice`
--

LOCK TABLES `tb_notice` WRITE;
/*!40000 ALTER TABLE `tb_notice` DISABLE KEYS */;
INSERT INTO `tb_notice` VALUES (2,'111','<p>1111</p>',0,1,1545425042,1536230347),(3,'如何赚佣','<p>如何赚佣在后台 公告管理---如何赚佣 ---编辑成自己想要的（不是删除是编辑）</p>',0,0,0,1545377542),(4,'广告投放','<p>广告投放 规则 在后台公告管理---广告投放 编辑成自己的投放规则（是编辑不是删除）</p>',0,0,0,1545377594),(5,'在线客服','<p>在线客服---在后台公告管理---在线客服 编辑内容 改成自己客服联系方式（是编辑不是删除）</p>',0,0,0,1545377647);
/*!40000 ALTER TABLE `tb_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_recharge`
--

DROP TABLE IF EXISTS `tb_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `credit2` decimal(10,2) DEFAULT '0.00' COMMENT '充值金额',
  `pay_method` tinyint(3) DEFAULT '0' COMMENT '0银行卡，1支付宝，2微信',
  `account` varchar(50) DEFAULT NULL COMMENT '账号',
  `realname` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `mobile` varchar(20) DEFAULT NULL COMMENT '手机号',
  `pay_time` varchar(50) DEFAULT NULL COMMENT '充值时间',
  `thumbs` varchar(255) NOT NULL DEFAULT '' COMMENT '充值截图',
  `status` tinyint(3) DEFAULT '0' COMMENT '0待审核，1已发放，-1审核未通过',
  `note` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_recharge`
--

LOCK TABLES `tb_recharge` WRITE;
/*!40000 ALTER TABLE `tb_recharge` DISABLE KEYS */;
INSERT INTO `tb_recharge` VALUES (105,184,'13888888888',188.00,0,'TD1545427537','',NULL,'','',0,NULL,1545427536,0),(106,184,'13888888888',99.00,0,'TD1545427666','',NULL,'','',0,NULL,1545427665,0),(107,184,'13888888888',1.00,0,'TD1545429743','',NULL,'2018-12-22 06:02:38','',1,'2018122222001400580502907988',1545429742,1545429758);
/*!40000 ALTER TABLE `tb_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_sign`
--

DROP TABLE IF EXISTS `tb_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_sign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `credit1` decimal(10,2) DEFAULT '0.00' COMMENT '赠送的积分',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid_create_time` (`uid`,`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='签到表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_sign`
--

LOCK TABLES `tb_sign` WRITE;
/*!40000 ALTER TABLE `tb_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_task`
--

DROP TABLE IF EXISTS `tb_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0' COMMENT '会员ID',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `repay_level` int(11) DEFAULT NULL,
  `detail` text,
  `category_id` int(11) DEFAULT '0' COMMENT '类别ID',
  `start_time` int(11) DEFAULT '0' COMMENT '开始时间',
  `end_time` int(11) DEFAULT '0' COMMENT '结束时间',
  `ticket_num` int(11) DEFAULT '0' COMMENT '票数',
  `join_num` int(11) DEFAULT '0' COMMENT '已加入的票数',
  `unit_price` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '任务单价',
  `give_credit1` int(10) unsigned DEFAULT '0' COMMENT '奖励积分',
  `give_credit2` decimal(10,2) DEFAULT '0.00' COMMENT '奖励金额',
  `fee` decimal(10,2) DEFAULT '0.00' COMMENT '手续费',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '任务总金额',
  `top_hour` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '置顶小时',
  `top_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '置顶时间',
  `top_fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '置顶费用',
  `top_end_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '置顶结束时间',
  `check_period` int(11) DEFAULT '0' COMMENT '审核周期，小时',
  `check_period_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '审核周期时间',
  `about_url` varchar(255) DEFAULT NULL COMMENT '相关地址',
  `check_text_content` varchar(255) NOT NULL DEFAULT '' COMMENT '文字验证',
  `remarks` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `is_screenshot` tinyint(3) DEFAULT '0' COMMENT '1需要截图',
  `is_ip_restriction` tinyint(3) DEFAULT '0' COMMENT '1限制IP',
  `province` varchar(20) DEFAULT NULL COMMENT '限制省份',
  `rate` tinyint(3) DEFAULT '0' COMMENT '0默认，1仅限一次，2每天一次，3定时任务',
  `interval_hour` int(11) DEFAULT '0' COMMENT '间隔时间',
  `is_limit_speed` tinyint(3) DEFAULT '0' COMMENT '1限速',
  `limit_ticket_num` int(11) DEFAULT '0' COMMENT '每5分钟限制票数',
  `thumbs` text COMMENT '任务多图',
  `order_by` int(11) DEFAULT '0',
  `is_display` tinyint(3) DEFAULT '1' COMMENT '1显示',
  `out_stock_flag` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '下架,0,未下架,1,下架 ',
  `out_stock_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下架时间',
  `is_complete` tinyint(3) DEFAULT '0' COMMENT '1已完成',
  `complete_time` int(11) DEFAULT '0' COMMENT '完成时间',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0',
  `audit_remarks` varchar(255) NOT NULL DEFAULT '' COMMENT '审核备注',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_task`
--

LOCK TABLES `tb_task` WRITE;
/*!40000 ALTER TABLE `tb_task` DISABLE KEYS */;
INSERT INTO `tb_task` VALUES (1,184,'官方每日任务1',NULL,'任务发布时请使用个人推广二维码一同发布！',6,1545324060,1576860060,100,0,20.00,1,2000.00,0.03,2060.00,0,0,0.00,0,0,1545324570,'','','微圈传媒平台，双赢模式无懈可击，用户代理收入来源于平台任务和代理，平台收入来源于广告位出租。 所以平台和代理双赢，\r\n每天两条朋友圈固定8元，你的代理每天任务完成你可以得到4元每个，微圈给了你自由发挥的空间，努力可以当事业打拼。不努力可以每天拿固定8元，躺赢模式躺到你舒服。',0,0,'0',1,0,0,0,'a:1:{i:0;s:45:\"20181221/cc4e1703ec6f51695fc9fb31c09b764f.png\";}',0,1,0,0,0,0,0,'',1545324570,1545324570),(2,184,'官方任务2',NULL,'微圈：\r\n1:零风险\r\nVIP会员约10天左右回本。\r\n2:无压力\r\n推广与不推广都有收益。\r\n3:好推广\r\n发朋友圈就可以轻松赚钱。\r\n4:大回报\r\n99元投资博日薪过千收入。\r\n5:没有人格风险\r\n不忽悠、不欺骗、真真实实能赚钱、养人脉\r\n6:人人都可以参与，低门槛，投资少。',6,1545325500,1576861500,1000,0,20.00,1,20000.00,0.03,20600.00,0,0,0.00,0,0,1545325641,'','','发圈2小时后再上传截图！',0,0,'0',1,0,0,0,'a:1:{i:0;s:45:\"20181221/2bc7c6de3dbb60a2807a5389c62f49ca.png\";}',0,1,0,0,0,0,0,'',1545325641,1545325641),(3,184,'官方任务1',NULL,'微圈：\r\n1:零风险\r\nVIP会员约10天左右回本。\r\n2:无压力\r\n推广与不推广都有收益。\r\n3:好推广\r\n发朋友圈就可以轻松赚钱。\r\n4:大回报\r\n99元投资博日薪过千收入。\r\n5:没有人格风险\r\n不忽悠、不欺骗、真真实实能赚钱、养人脉\r\n6:人人都可以参与，低门槛，投资少。',4,1545325620,1576861620,1000,1,8.00,1,8000.00,0.03,8240.00,0,0,0.00,0,0,1545325729,'','','发圈2小时+使用个人推广二维码！',0,0,'0',1,0,0,0,'a:1:{i:0;s:45:\"20181221/44eabe99e2fdfc1b0a6e9201c46792c1.png\";}',0,1,0,0,0,0,0,'',1545325729,1545325729),(4,184,'官方任务2',NULL,'微圈传媒平台，双赢模式无懈可击，用户代理收入来源于平台任务和代理，平台收入来源于广告位出租。 所以平台和代理双赢，\r\n每天两条朋友圈固定8元，你的代理每天任务完成你可以得到4元每个，微圈给了你自由发挥的空间，努力可以当事业打拼。不努力可以每天拿固定8元，躺赢模式躺到你舒服。',4,1545325740,1576861740,1000,0,8.00,1,8000.00,0.03,8240.00,0,0,0.00,0,0,1545325852,'','','发圈2小时+朋友圈发布个人推广二维码或者链接！',0,0,'0',1,0,0,0,'a:1:{i:0;s:45:\"20181221/5d970599cbf9d59ca435e2a861da749a.png\";}',0,1,0,0,0,0,0,'',1545325852,1545325852),(5,184,'官方任务1',NULL,'微圈传媒平台，双赢模式无懈可击，用户代理收入来源于平台任务和代理，平台收入来源于广告位出租。 所以平台和代理双赢，\r\n每天两条朋友圈固定8元，你的代理每天任务完成你可以得到4元每个，微圈给了你自由发挥的空间，努力可以当事业打拼。不努力可以每天拿固定8元，躺赢模式躺到你舒服。',3,1545325920,1576861920,10000,0,4.00,1,40000.00,0.03,41200.00,0,0,0.00,0,0,1545326003,'','','发圈2小时+个人推广二维码或者个人推广链接即可！',0,0,'0',1,0,0,0,'a:1:{i:0;s:45:\"20181221/653c587dc284a00d7bfc1aba81871861.png\";}',0,1,0,0,0,0,0,'',1545326003,1545326003),(6,184,'官方任务2',NULL,'微圈：\r\n1:零风险\r\nVIP会员约10天左右回本。\r\n2:无压力\r\n推广与不推广都有收益。\r\n3:好推广\r\n发朋友圈就可以轻松赚钱。\r\n4:大回报\r\n99元投资博日薪过千收入。\r\n5:没有人格风险\r\n不忽悠、不欺骗、真真实实能赚钱、养人脉\r\n6:人人都可以参与，低门槛，投资少。',3,1545325980,1576861980,10000,1,4.00,1,40000.00,0.03,41200.00,0,0,0.00,0,0,1545326126,'','','发圈2小时+个人推广二维码或者链接即可！',0,0,'0',1,0,0,0,'a:1:{i:0;s:45:\"20181221/2c31480840a3f49322880feeb6e8197c.png\";}',0,1,0,0,0,0,0,'',1545326126,1545326126);
/*!40000 ALTER TABLE `tb_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_task_category`
--

DROP TABLE IF EXISTS `tb_task_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_task_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) DEFAULT NULL COMMENT '分类名称',
  `only_level` int(11) NOT NULL DEFAULT '1',
  `thumb` varchar(255) DEFAULT NULL COMMENT '分类图片',
  `min_give_credit1` decimal(10,2) DEFAULT '0.00' COMMENT '最小奖励积分',
  `min_give_credit2` decimal(10,2) DEFAULT '0.00' COMMENT '最小奖励金额',
  `order_by` int(11) DEFAULT '0' COMMENT '数字越大越靠前',
  `is_display` tinyint(3) DEFAULT '1' COMMENT '1显示',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_task_category`
--

LOCK TABLES `tb_task_category` WRITE;
/*!40000 ALTER TABLE `tb_task_category` DISABLE KEYS */;
INSERT INTO `tb_task_category` VALUES (2,'自由任务',1,'20180208/64cdf4d5938c667cdb5f77b537050ce4.png',0.00,0.10,0,1,1544121696,1516799416),(3,'VIP任务区',2,'20180208/d034900fe0a115b50abe2c2bab0f2a0d.png',0.00,2.00,1,1,1544121741,1516799441),(4,'高级VIP任务',3,'20180208/f52ecf12b5cf8df1efc081db58ddbbfc.png',0.00,4.00,2,1,1544121788,1516799454),(6,'特级VIP任务',4,'20180208/1de21bf1891a1a88d6dd384e0600e6be.png',0.00,20.00,3,1,1544420810,1516799487);
/*!40000 ALTER TABLE `tb_task_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_task_join`
--

DROP TABLE IF EXISTS `tb_task_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_task_join` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '接单id',
  `task_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '任务id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `thumbs` text COMMENT '审核图样',
  `check_text_content` varchar(255) NOT NULL DEFAULT '' COMMENT '文字确认',
  `communication` varchar(255) NOT NULL DEFAULT '' COMMENT '信息交流',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '接单状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '接单时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `audit_time` int(10) unsigned NOT NULL DEFAULT '0',
  `delflag` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '删除标识  1.未删除 2.假删除',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务接单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_task_join`
--

LOCK TABLES `tb_task_join` WRITE;
/*!40000 ALTER TABLE `tb_task_join` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_task_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_task_operate_steps`
--

DROP TABLE IF EXISTS `tb_task_operate_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_task_operate_steps` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '操作id',
  `task_id` int(11) NOT NULL DEFAULT '0' COMMENT '任务id',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `content` text COMMENT '操作说明文字',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '操作说明配图',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '操作步骤顺序',
  `update_time` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COMMENT='操作说明表  与发布任务表关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_task_operate_steps`
--

LOCK TABLES `tb_task_operate_steps` WRITE;
/*!40000 ALTER TABLE `tb_task_operate_steps` DISABLE KEYS */;
INSERT INTO `tb_task_operate_steps` VALUES (68,31,184,'123','',0,0,1545426619);
/*!40000 ALTER TABLE `tb_task_operate_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_uploads`
--

DROP TABLE IF EXISTS `tb_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT '0' COMMENT '管理员ID',
  `uid` int(11) DEFAULT '0' COMMENT '会员ID',
  `extension` varchar(20) DEFAULT NULL COMMENT '扩展名',
  `original_name` varchar(255) DEFAULT NULL COMMENT '原文件名',
  `save_name` varchar(255) DEFAULT NULL COMMENT '保存名称',
  `filename` varchar(255) DEFAULT NULL COMMENT '文件名',
  `md5` varchar(255) DEFAULT NULL COMMENT '文件md5',
  `sha1` varchar(255) DEFAULT NULL COMMENT '文件sha1值',
  `size` varchar(255) DEFAULT NULL COMMENT '文件大小',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='上传信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_uploads`
--

LOCK TABLES `tb_uploads` WRITE;
/*!40000 ALTER TABLE `tb_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_withdraw`
--

DROP TABLE IF EXISTS `tb_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_withdraw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `credit2` decimal(10,2) DEFAULT '0.00' COMMENT '提现金额',
  `fee` decimal(10,2) DEFAULT '0.00' COMMENT '手续费',
  `pay_method` tinyint(3) DEFAULT '0' COMMENT '0银行卡，1支付宝，2微信',
  `account` varchar(50) DEFAULT NULL COMMENT '账号',
  `realname` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `mobile` varchar(20) DEFAULT NULL COMMENT '手机号',
  `status` tinyint(3) DEFAULT '0' COMMENT '0待审核，1已发放，-1审核未通过',
  `note` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `update_time` int(11) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_withdraw`
--

LOCK TABLES `tb_withdraw` WRITE;
/*!40000 ALTER TABLE `tb_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_stop`
--

DROP TABLE IF EXISTS `user_stop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_stop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(41) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_stop`
--

LOCK TABLES `user_stop` WRITE;
/*!40000 ALTER TABLE `user_stop` DISABLE KEYS */;
INSERT INTO `user_stop` VALUES (8,'223.104.65.32','2019-03-08 12:25:29');
/*!40000 ALTER TABLE `user_stop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_admin`
--

DROP TABLE IF EXISTS `zh_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user` varchar(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `passwd` char(40) NOT NULL DEFAULT '' COMMENT '密码',
  `email` varchar(60) NOT NULL DEFAULT '' COMMENT '邮箱',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_admin`
--

LOCK TABLES `zh_admin` WRITE;
/*!40000 ALTER TABLE `zh_admin` DISABLE KEYS */;
INSERT INTO `zh_admin` VALUES (1,'admin','d7c0a7a4080d0cb059e98299f9cae690','3823903@qq.com');
/*!40000 ALTER TABLE `zh_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_config`
--

DROP TABLE IF EXISTS `zh_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_config` (
  `id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(100) DEFAULT NULL,
  `site_name` varchar(100) DEFAULT NULL,
  `qq` varchar(20) DEFAULT NULL,
  `yumingchi` text NOT NULL,
  `home_url` varchar(200) NOT NULL,
  `codepay_id` varchar(200) NOT NULL,
  `codepay_key` varchar(200) NOT NULL,
  `user` varchar(100) NOT NULL,
  `db_name` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `api_key` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_config`
--

LOCK TABLES `zh_config` WRITE;
/*!40000 ALTER TABLE `zh_config` DISABLE KEYS */;
INSERT INTO `zh_config` VALUES (1,'88888a.cn','幸运防封V5.0','2604498096','','demo.18845.cn','','','demo_18845','demo_18845','GB5WhKB4PrsChYaD','');
/*!40000 ALTER TABLE `zh_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_domain`
--

DROP TABLE IF EXISTS `zh_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_domain`
--

LOCK TABLES `zh_domain` WRITE;
/*!40000 ALTER TABLE `zh_domain` DISABLE KEYS */;
INSERT INTO `zh_domain` VALUES (1,'bbs.0766city.com','2018-10-07 19:35:21',1);
/*!40000 ALTER TABLE `zh_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_iptable`
--

DROP TABLE IF EXISTS `zh_iptable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_iptable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_iptable`
--

LOCK TABLES `zh_iptable` WRITE;
/*!40000 ALTER TABLE `zh_iptable` DISABLE KEYS */;
INSERT INTO `zh_iptable` VALUES (5,'223.104.20.142','2018-10-29 21:34:40',2);
/*!40000 ALTER TABLE `zh_iptable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_log`
--

DROP TABLE IF EXISTS `zh_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) DEFAULT NULL,
  `click_time` date DEFAULT '0000-00-00',
  `user_agent` varchar(255) NOT NULL,
  `ip_address` varchar(41) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_log`
--

LOCK TABLES `zh_log` WRITE;
/*!40000 ALTER TABLE `zh_log` DISABLE KEYS */;
INSERT INTO `zh_log` VALUES (69,'8803020.COM','2019-03-08','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36','113.61.54.213'),(70,'8803020.COM','2019-03-09','Mozilla/5.0 (Unknown; Linux x86_64) AppleWebKit/538.1 (KHTML, like Gecko) PhantomJS/2.1.1 Safari/538.1','106.11.223.179'),(71,'8803020.COM','2019-03-09','Mozilla/5.0 (Unknown; Linux x86_64) AppleWebKit/538.1 (KHTML, like Gecko) PhantomJS/2.1.1 Safari/538.1','106.11.223.179'),(72,'8803020.COM','2019-03-09','Mozilla/5.0 (Linux; Android 4.4.2; vivo X710L Build/KVT49L; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.49 Mobile MQQBrowser/6.2 TBS/043128 Safari/537.36 MicroMessenger/6.5.7.1041 NetType/4G Language/zh_CN','203.119.132.69');
/*!40000 ALTER TABLE `zh_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_luodi`
--

DROP TABLE IF EXISTS `zh_luodi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_luodi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL DEFAULT '0',
  `domain` varchar(200) NOT NULL,
  `time` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `type` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=384 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_luodi`
--

LOCK TABLES `zh_luodi` WRITE;
/*!40000 ALTER TABLE `zh_luodi` DISABLE KEYS */;
INSERT INTO `zh_luodi` VALUES (383,0,'ss.88888a.cn','1552194867',1,1),(382,0,'88888a.cn','1551971487',1,0);
/*!40000 ALTER TABLE `zh_luodi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_member`
--

DROP TABLE IF EXISTS `zh_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_member` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `key` varchar(100) NOT NULL,
  `dengji` int(10) NOT NULL DEFAULT '0',
  `daoqitime` int(10) NOT NULL DEFAULT '0',
  `money` varchar(10) NOT NULL,
  `qq` int(11) NOT NULL,
  `statu` int(11) NOT NULL,
  `zctime` varchar(20) NOT NULL,
  `tiaonum` int(10) NOT NULL DEFAULT '0',
  `ffapi` int(11) NOT NULL DEFAULT '0',
  `dlurl` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_member`
--

LOCK TABLES `zh_member` WRITE;
/*!40000 ALTER TABLE `zh_member` DISABLE KEYS */;
INSERT INTO `zh_member` VALUES (78,'xiaolei','3a300c48b47b714d9821dc473304aa84','M0OSJxpEKmojySs',0,2147483647,'137796',11386465,1,'1551965904',565151,1,'');
/*!40000 ALTER TABLE `zh_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_order`
--

DROP TABLE IF EXISTS `zh_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(20) NOT NULL,
  `out_order_id` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `realprice` int(10) NOT NULL,
  `type` varchar(50) NOT NULL,
  `paytime` int(20) NOT NULL,
  `extend` varchar(100) NOT NULL,
  `sign` int(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_order`
--

LOCK TABLES `zh_order` WRITE;
/*!40000 ALTER TABLE `zh_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `zh_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_report`
--

DROP TABLE IF EXISTS `zh_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(10) DEFAULT '',
  `url` varchar(64) DEFAULT NULL,
  `short` varchar(250) NOT NULL,
  `reason` varchar(20) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '0',
  `user_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_report`
--

LOCK TABLES `zh_report` WRITE;
/*!40000 ALTER TABLE `zh_report` DISABLE KEYS */;
INSERT INTO `zh_report` VALUES (76,'','http://18845.cn','http://t.cn/EMGjxbf','生成记录','113.61.54.147','2019-03-10 13:15:36',1,0,48);
/*!40000 ALTER TABLE `zh_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_siteconfig`
--

DROP TABLE IF EXISTS `zh_siteconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_siteconfig` (
  `k` varchar(32) NOT NULL,
  `v` text,
  PRIMARY KEY (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_siteconfig`
--

LOCK TABLES `zh_siteconfig` WRITE;
/*!40000 ALTER TABLE `zh_siteconfig` DISABLE KEYS */;
INSERT INTO `zh_siteconfig` VALUES ('bdtjid','b48b430d2fe4cb01949c588b2ccfd5ba'),('cc_module','1'),('cnzzid','1273386416'),('cronkey','fanghongmiyao'),('description','域名防洪系统'),('dwzapi','1'),('go_file','/t.php'),('go_type','0'),('homestyle','51fh.uomg'),('keywords','域名防洪系统'),('qid','123456'),('apikey','4RcoHtcsaB'),('mail_tips','1'),('name','域名防洪系统'),('qq_report','1'),('show_home','1'),('sitename','域名防洪系统'),('siteurl','http://v5.fangfengfuwu.cn'),('kfqq','43438142'),('stasis_anqq','default.uomg'),('stasis_iosqq','default.uomg'),('stasis_other','default.uomg'),('stasis_weixin','default.uomg'),('threshold','20'),('txprotect','1'),('t_go_delay','500'),('t_go_format','css'),('t_go_url','no'),('t_ip_url',''),('t_weixin_url','');
/*!40000 ALTER TABLE `zh_siteconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh_user`
--

DROP TABLE IF EXISTS `zh_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '商户名称',
  `url` varchar(255) DEFAULT NULL COMMENT '原始url',
  `tourl` varchar(255) DEFAULT NULL COMMENT '转换后url',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `expiretime` int(10) DEFAULT '0' COMMENT '到期时间',
  `hits` int(11) DEFAULT '0' COMMENT '当前访问次数',
  `tiao` int(1) DEFAULT '0' COMMENT '1跳转',
  `uid` int(10) DEFAULT NULL,
  `disable` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `key` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=437 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh_user`
--

LOCK TABLES `zh_user` WRITE;
/*!40000 ALTER TABLE `zh_user` DISABLE KEYS */;
INSERT INTO `zh_user` VALUES (436,'http://55581.com','http://55581.com','http://t.cn/EMLJCYa',1552132872,2147483647,3,1,NULL,1,'','');
/*!40000 ALTER TABLE `zh_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-10 13:16:34
